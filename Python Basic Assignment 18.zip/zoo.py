#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def hours(): 
    print ( 'Open 9-5 daily')

